// features/vault/vault.ts
import * as FileSystem from 'expo-file-system';
import * as SecureStore from 'expo-secure-store';
import * as LocalAuth from 'expo-local-authentication';
import CryptoJS from 'crypto-js';
import { v4 as uuidv4 } from 'uuid';

const VAULT_KEY_ID = 'velox_vault_key_v1';
const VAULT_DIR = `${FileSystem.documentDirectory}velox_vault/`;

async function ensureVaultDir() {
  const info = await FileSystem.getInfoAsync(VAULT_DIR);
  if (!info.exists) {
    await FileSystem.makeDirectoryAsync(VAULT_DIR, { intermediates: true });
  }
}

async function generateAndStoreKey() {
  const key = CryptoJS.lib.WordArray.random(32).toString();
  await SecureStore.setItemAsync(VAULT_KEY_ID, key, { keychainAccessible: SecureStore.ALWAYS_THIS_DEVICE_ONLY });
  return key;
}

export async function ensureKeyExists() {
  let key = await SecureStore.getItemAsync(VAULT_KEY_ID);
  if (!key) {
    key = await generateAndStoreKey();
  }
  return key!;
}

export async function lockWithBiometrics(): Promise<boolean> {
  const hasHardware = await LocalAuth.hasHardwareAsync();
  if (!hasHardware) return false;
  const enrolled = await LocalAuth.isEnrolledAsync();
  if (!enrolled) return false;
  const result = await LocalAuth.authenticateAsync({
    promptMessage: 'Unlock Private Vault',
    fallbackLabel: 'Use device passcode',
  });
  return result.success;
}

export async function encryptFileToVault(localUri: string) {
  await ensureVaultDir();
  const key = await ensureKeyExists();
  const base64 = await FileSystem.readAsStringAsync(localUri, { encoding: FileSystem.EncodingType.Base64 });
  const ciphertext = CryptoJS.AES.encrypt(base64, key).toString();
  const id = uuidv4();
  const dest = `${VAULT_DIR}${id}.enc`;
  await FileSystem.writeAsStringAsync(dest, ciphertext, { encoding: FileSystem.EncodingType.UTF8 });
  return { id, path: dest };
}

export async function decryptVaultFile(id: string, destFilename?: string) {
  const canUnlock = await lockWithBiometrics();
  if (!canUnlock) throw new Error('Biometric unlock failed');

  const key = await SecureStore.getItemAsync(VAULT_KEY_ID);
  if (!key) throw new Error('Vault key missing');

  const src = `${VAULT_DIR}${id}.enc`;
  const exists = await FileSystem.getInfoAsync(src);
  if (!exists.exists) throw new Error('Vault file missing');
  const ciphertext = await FileSystem.readAsStringAsync(src, { encoding: FileSystem.EncodingType.UTF8 });
  const bytes = CryptoJS.AES.decrypt(ciphertext, key);
  const base64 = bytes.toString(CryptoJS.enc.Utf8);

  const outName = destFilename || `${uuidv4()}.bin`;
  const outPath = `${FileSystem.cacheDirectory}${outName}`;
  await FileSystem.writeAsStringAsync(outPath, base64, { encoding: FileSystem.EncodingType.Base64 });
  return outPath;
}

export async function listVaultFiles() {
  await ensureVaultDir();
  const contents = await FileSystem.readDirectoryAsync(VAULT_DIR);
  return contents.filter((n) => n.endsWith('.enc')).map((n) => ({ id: n.replace('.enc', ''), name: n }));
}