// features/flow/downloadController.ts
import { EventEmitter } from 'events';
import { startDownloads, onProgress as onDlProgress, onDone as onDlDone, onError as onDlError, stopSession } from '../downloader/downloader';
import { muxStreams, onMuxProgress, onMuxDone, onMuxError } from '../muxer/mediaMuxer';
import * as MediaLibrary from 'expo-media-library';
import { startForegroundService, stopForegroundService, updateNotification } from '../../src/native/ForegroundService';

/**
 * Orchestrates downloads + muxing and updates the foreground notification with progress & status.
 */

export type ControllerEvents = 'status' | 'downloadProgress' | 'downloadDone' | 'muxProgress' | 'muxDone' | 'error';

const emitter = new EventEmitter();

let currentSessionId: string | null = null;
let downloadItemMap: Record<string, { type: 'video' | 'audio'; localUri?: string }> = {};

function normalizePath(uri: string) {
  if (!uri) return uri;
  return uri.startsWith('file://') ? uri.replace('file://', '') : uri;
}

export function on(event: ControllerEvents, cb: (...args: any[]) => void) {
  emitter.addListener(event, cb);
  return () => emitter.removeListener(event, cb);
}

export async function runDownloadAndMux(inputs: { videoUrl: string; audioUrl: string; suggestedFilename?: string; }) {
  const { videoUrl, audioUrl, suggestedFilename } = inputs;
  emitter.emit('status', 'starting');

  // Start foreground service
  await startForegroundService('Velox', 'Starting download');
  // initial notification
  await updateNotification('Velox', 'Starting download', 0);

  emitter.emit('status', 'downloading');

  const videoId = `video-${Date.now()}-v`;
  const audioId = `audio-${Date.now()}-a`;

  downloadItemMap = {};
  downloadItemMap[videoId] = { type: 'video' };
  downloadItemMap[audioId] = { type: 'audio' };

  // subscribe to events
  const dlProgressUnsub = onDlProgress((p: any) => {
    emitter.emit('downloadProgress', p);
    // Update notification: compute approximate overall percent average of the two items
    try {
      const itemId = p.itemId as string;
      const pct = p.percentage || 0;
      if (itemId.startsWith('video')) {
        // store latest
        downloadItemMap[itemId] = { ...downloadItemMap[itemId], localUri: downloadItemMap[itemId]?.localUri };
      }
      // compute average of known percentages; we only get individual progress; approximate overall
      const known = Object.keys(downloadItemMap);
      let sum = 0;
      let count = 0;
      for (const k of known) {
        const meta = (k === p.itemId) ? { ...downloadItemMap[k], lastPct: pct } : downloadItemMap[k];
        const lastPct = (meta as any).lastPct || 0;
        sum += lastPct;
        count++;
      }
      const overall = count > 0 ? Math.round(sum / count) : Math.round(pct);
      updateNotification('Velox', `Downloading (${Math.round(overall)}%)`, overall).catch(() => {});
    } catch (e) {}
  });

  const dlDoneUnsub = onDlDone((d: any) => {
    emitter.emit('downloadDone', d);
    // record localUri
    if (d && d.itemId) {
      downloadItemMap[d.itemId] = { ...(downloadItemMap[d.itemId] || { type: 'other' }), localUri: d.localUri };
    }

    // check if both audio & video exist
    const entries = Object.entries(downloadItemMap);
    const videoEntry = entries.find(([, meta]) => meta.type === 'video' && meta.localUri);
    const audioEntry = entries.find(([, meta]) => meta.type === 'audio' && meta.localUri);

    if (videoEntry && audioEntry) {
      proceedToMux(videoEntry[1].localUri!, audioEntry[1].localUri!, suggestedFilename || `velox_${Date.now()}`);
    }
  });

  const dlErrUnsub = onDlError((e) => {
    emitter.emit('error', e);
    updateNotification('Velox', 'Download error', null).catch(() => {});
  });

  try {
    currentSessionId = await startDownloads(null, [
      { id: videoId, url: videoUrl, filename: suggestedFilename ? `${suggestedFilename}.mp4` : undefined, type: 'video' },
      { id: audioId, url: audioUrl, filename: suggestedFilename ? `${suggestedFilename}.m4a` : undefined, type: 'audio' },
    ]);
  } catch (e) {
    emitter.emit('error', { message: 'Download start failed', error: e });
    updateNotification('Velox', 'Download failed', null).catch(() => {});
    await stopForegroundService();
    return;
  }

  let muxStarted = false;

  async function proceedToMux(videoLocalUri: string, audioLocalUri: string, outNameBase: string) {
    if (muxStarted) return;
    muxStarted = true;

    emitter.emit('status', 'muxing');
    updateNotification('Velox', 'Muxing media', 0).catch(() => {});

    const vPath = normalizePath(videoLocalUri);
    const aPath = normalizePath(audioLocalUri);

    const muxProgUnsub = onMuxProgress((p: any) => {
      emitter.emit('muxProgress', p);
      // p.time contains seconds processed; we don't know total duration; show indeterminate via -1 or show time.
      // We'll update notification with a simple spinner-like percent if we can guess; otherwise show time
      if (p && typeof p.time === 'number') {
        const approxPct = Math.min(100, Math.round(Math.min(p.time / 60.0, 1) * 100)); // naive: assume <=60s means 100%
        updateNotification('Velox', `Muxing (${approxPct}%)`, approxPct).catch(() => {});
      } else {
        updateNotification('Velox', 'Muxing', null).catch(() => {});
      }
    });

    const muxDoneUnsub = onMuxDone(async ({ id, outputPath }: any) => {
      emitter.emit('muxDone', { id, outputPath });
      updateNotification('Velox', 'Saving output', 100).catch(() => {});

      try {
        const cleaned = outputPath.startsWith('file://') ? outputPath.replace('file://', '') : outputPath;
        const { status } = await MediaLibrary.requestPermissionsAsync();
        if (status === 'granted') {
          const asset = await MediaLibrary.createAssetAsync(cleaned);
          const albumName = 'Movies/Velox';
          let album = await MediaLibrary.getAlbumAsync(albumName);
          if (!album) {
            album = await MediaLibrary.createAlbumAsync(albumName, asset, false);
          } else {
            await MediaLibrary.addAssetsToAlbumAsync([asset], album.id, false);
          }
        }
        emitter.emit('status', 'done');
        updateNotification('Velox', 'Done', 100).catch(() => {});
      } catch (e) {
        emitter.emit('error', { message: 'Saving output failed', error: e });
        updateNotification('Velox', 'Save failed', null).catch(() => {});
      } finally {
        // Stop service after short delay so user sees Done
        setTimeout(async () => {
          await stopForegroundService();
        }, 800);
        // cleanup
        muxProgUnsub();
        muxDoneUnsub();
      }
    });

    const muxErrUnsub = onMuxError(async (p: any) => {
      emitter.emit('error', p);
      updateNotification('Velox', 'Muxing error', null).catch(() => {});
      muxProgUnsub();
      muxDoneUnsub();
      await stopForegroundService();
    });

    try {
      await muxStreams(vPath, aPath);
    } catch (e) {
      emitter.emit('error', { message: 'Mux start failed', error: e });
      updateNotification('Velox', 'Mux start failed', null).catch(() => {});
      await stopForegroundService();
    }
  }

  return {
    cancel: async () => {
      try {
        if (currentSessionId) {
          stopSession(currentSessionId);
        }
        await stopForegroundService();
        emitter.emit('status', 'cancelled');
      } catch (e) {}
    },
    sessionId: currentSessionId,
    off: () => {
      dlProgressUnsub && dlProgressUnsub();
      dlDoneUnsub && dlDoneUnsub();
      dlErrUnsub && dlErrUnsub();
    },
  };
}