// features/browser/IncognitoWebView.tsx
import React, { useRef, useCallback } from 'react';
import { View, StyleSheet } from 'react-native';
import WebView, { WebViewMessageEvent } from 'react-native-webview';

type Props = {
  initialUrl?: string;
  onStreamDetected?: (url: string) => void;
  incognito?: boolean;
};

const injectedJS = `
(function () {
  function tryDetectMediaFromElement(el) {
    try {
      if (!el) return;
      if (el.tagName && (el.tagName.toLowerCase() === 'video' || el.tagName.toLowerCase() === 'audio')) {
        if (el.src) {
          window.ReactNativeWebView.postMessage(JSON.stringify({type: 'media', url: el.src}));
        } else {
          var src = el.querySelector('source');
          if (src && src.src) {
            window.ReactNativeWebView.postMessage(JSON.stringify({type: 'media', url: src.src}));
          }
        }
      }
    } catch (e) {}
  }

  var obs = new MutationObserver(function(mutations) {
    mutations.forEach(function(m) {
      m.addedNodes.forEach(function(node) {
        tryDetectMediaFromElement(node);
      });
    });
  });
  obs.observe(document, { childList: true, subtree: true });

  (function(open) {
    var send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function() {
      this.addEventListener('load', function() {
        try {
          var url = this.responseURL || '';
          if (url.match(/\\.(mp4|m3u8|mp3|aac|m4a|webm|wav)(\\?.*)?$/i)) {
            window.ReactNativeWebView.postMessage(JSON.stringify({type: 'media', url: url}));
          }
        } catch(e){}
      });
      return open.apply(this, arguments);
    };
  })(XMLHttpRequest.prototype.open);

  (function(fetch) {
    window.fetch = function() {
      return fetch.apply(this, arguments).then(function(resp) {
        try {
          var url = resp.url || '';
          if (url.match(/\\.(mp4|m3u8|mp3|aac|m4a|webm|wav)(\\?.*)?$/i)) {
            window.ReactNativeWebView.postMessage(JSON.stringify({type: 'media', url: url}));
          }
        } catch(e){}
        return resp;
      });
    };
  })(window.fetch);

  window.ReactNativeWebView.postMessage(JSON.stringify({type: 'ready'}));
})();
`;

export default function IncognitoWebView({ initialUrl = 'https://example.com', onStreamDetected, incognito = true }: Props) {
  const ref = useRef<WebView>(null);

  const handleMessage = useCallback(
    (e: WebViewMessageEvent) => {
      try {
        const data = JSON.parse(e.nativeEvent.data);
        if (data?.type === 'media' && data?.url) {
          onStreamDetected && onStreamDetected(data.url);
        }
      } catch (err) {}
    },
    [onStreamDetected]
  );

  return (
    <View style={styles.container}>
      <WebView
        ref={ref}
        source={{ uri: initialUrl }}
        originWhitelist={['*']}
        incognito={incognito}
        javaScriptEnabled
        domStorageEnabled={false}
        sharedCookiesEnabled={false}
        thirdPartyCookiesEnabled={false}
        injectedJavaScript={injectedJS}
        onMessage={handleMessage}
        startInLoadingState
        allowsInlineMediaPlayback
        mediaPlaybackRequiresUserAction={false}
        style={styles.webview}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B0B0C' },
  webview: { flex: 1, backgroundColor: '#0B0B0C' },
});