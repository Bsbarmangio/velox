// features/queue/DownloadQueueScreen.tsx
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';

type RouteParams = {
  params?: {
    detectedUrl?: string | null;
    autoStart?: boolean;
  };
};

export default function DownloadQueueScreen() {
  const navigation = useNavigation();
  const route = useRoute() as RouteProp<Record<string, RouteParams>, string>;
  const detected = route.params?.detectedUrl ?? null;
  const autoStart = route.params?.autoStart ?? false;

  // Allow user to provide separate video + audio stream URLs.
  const [videoUrl, setVideoUrl] = useState<string>(detected ?? '');
  const [audioUrl, setAudioUrl] = useState<string>(detected ?? '');

  useEffect(() => {
    if (detected) {
      setVideoUrl(detected);
      setAudioUrl(detected);
    }
  }, [detected]);

  useEffect(() => {
    // If autoStart is true, give a short UI beat then route to Manager to start downloads automatically.
    if (autoStart && videoUrl) {
      const t = setTimeout(() => {
        navigation.replace('Manager' as any, { videoUrl, audioUrl });
      }, 350); // small delay to show queue briefly
      return () => clearTimeout(t);
    }
  }, [autoStart, videoUrl, audioUrl, navigation]);

  const onStart = () => {
    navigation.navigate('Manager' as any, { videoUrl, audioUrl });
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.select({ ios: 'padding', android: undefined })}>
      <View style={styles.content}>
        <Text style={styles.title}>Prepare Download</Text>

        <Text style={styles.label}>Video Stream URL</Text>
        <TextInput
          value={videoUrl}
          onChangeText={setVideoUrl}
          placeholder="https://..."
          placeholderTextColor="#8F9B9A"
          style={styles.input}
          autoCapitalize="none"
          autoCorrect={false}
        />

        <Text style={[styles.label, { marginTop: 12 }]}>Audio Stream URL</Text>
        <TextInput
          value={audioUrl}
          onChangeText={setAudioUrl}
          placeholder="https://..."
          placeholderTextColor="#8F9B9A"
          style={styles.input}
          autoCapitalize="none"
          autoCorrect={false}
        />

        <TouchableOpacity style={styles.startButton} onPress={onStart}>
          <Text style={styles.startText}>Start Download & Mux</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.cancelButton} onPress={() => navigation.goBack()}>
          <Text style={{ color: '#00F2EA' }}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B0B0C' },
  content: { padding: 16, marginTop: 24 },
  title: { color: '#E6F7F6', fontSize: 20, fontWeight: '700', marginBottom: 12 },
  label: { color: '#8F9B9A', marginBottom: 6 },
  input: {
    backgroundColor: '#0F0F10',
    color: '#E6F7F6',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 10,
  },
  startButton: {
    marginTop: 20,
    backgroundColor: '#00F2EA',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  startText: { color: '#021212', fontWeight: '700' },
  cancelButton: { marginTop: 12, alignItems: 'center' },
});