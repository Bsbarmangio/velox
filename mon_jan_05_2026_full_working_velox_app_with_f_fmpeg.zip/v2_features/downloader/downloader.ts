// features/downloader/downloader.ts
import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';

/**
 * High-performance downloader:
 * - Uses Expo FileSystem.createDownloadResumable for resumable downloads
 * - Supports parallel downloads (controlled concurrency)
 * - Emits progress/done/error events
 */

export type DownloadItem = {
  id?: string;
  url: string;
  filename?: string;
  type?: 'video' | 'audio' | 'other';
};

export type ProgressPayload = {
  sessionId: string;
  itemId: string;
  bytesWritten: number;
  contentLength: number;
  percentage: number;
};

const emitter = new EventEmitter();
const sessions: Record<string, { resumables: Record<string, FileSystem.DownloadResumable | null>; active: boolean }> = {};

async function saveToMediaLibrary(localUri: string, type: 'video' | 'audio' | 'other') {
  try {
    const asset = await MediaLibrary.createAssetAsync(localUri);
    const albumName = type === 'audio' ? 'Music/Velox' : 'Movies/Velox';
    let album = await MediaLibrary.getAlbumAsync(albumName);
    if (!album) {
      album = await MediaLibrary.createAlbumAsync(albumName, asset, false);
    } else {
      await MediaLibrary.addAssetsToAlbumAsync([asset], album.id, false);
    }
    return asset;
  } catch (e) {
    console.warn('saveToMediaLibrary failed', e);
    return null;
  }
}

export async function startDownloads(sessionId: string | null, items: DownloadItem[]) {
  const id = sessionId || uuidv4();
  sessions[id] = { resumables: {}, active: true };
  const { status } = await MediaLibrary.requestPermissionsAsync();
  const granted = status === 'granted';

  const concurrency = 2;
  let index = 0;

  async function worker() {
    while (sessions[id].active && index < items.length) {
      const item = items[index++];
      const itemId = item.id || uuidv4();
      const ext = (item.filename && item.filename.split('.').pop()) || 'mp4';
      const localUri = `${FileSystem.cacheDirectory}${itemId}.${ext}`;

      try {
        const resumable = FileSystem.createDownloadResumable(
          item.url,
          localUri,
          {},
          (dp) => {
            const { totalBytesWritten, totalBytesExpectedToWrite } = dp;
            const percentage = totalBytesExpectedToWrite > 0 ? (totalBytesWritten / totalBytesExpectedToWrite) * 100 : 0;
            const p: ProgressPayload = { sessionId: id, itemId, bytesWritten: totalBytesWritten, contentLength: totalBytesExpectedToWrite, percentage };
            emitter.emit('progress', p);
          }
        );

        sessions[id].resumables[itemId] = resumable;
        const result = await resumable.downloadAsync();
        if (granted) {
          await saveToMediaLibrary(result.uri, item.type || 'other');
        }
        emitter.emit('done', { sessionId: id, itemId, localUri: result.uri });
      } catch (e) {
        emitter.emit('error', { sessionId: id, itemId, error: e });
      }
    }
    sessions[id].active = false;
  }

  const runners = [];
  for (let i = 0; i < concurrency; i++) runners.push(worker());
  await Promise.all(runners);

  return id;
}

export function onProgress(cb: (p: ProgressPayload) => void) {
  emitter.addListener('progress', cb);
  return () => emitter.removeListener('progress', cb);
}
export function onDone(cb: (p: { sessionId: string; itemId: string; localUri: string }) => void) {
  emitter.addListener('done', cb);
  return () => emitter.removeListener('done', cb);
}
export function onError(cb: (p: { sessionId: string; itemId: string; error: any }) => void) {
  emitter.addListener('error', cb);
  return () => emitter.removeListener('error', cb);
}
export function stopSession(sessionId: string) {
  const s = sessions[sessionId];
  if (!s) return;
  s.active = false;
  Object.values(s.resumables).forEach((r) => {
    try {
      r && (r as any).pauseAsync && (r as any).pauseAsync();
    } catch (e) {}
  });
  emitter.emit('stopped', { sessionId });
}