// features/muxer/mediaMuxer.ts
import { FFmpegKit, FFprobeKit, ReturnCode } from 'ffmpeg-kit-react-native';
import { EventEmitter } from 'events';
import * as FileSystem from 'expo-file-system';
import { v4 as uuidv4 } from 'uuid';

/**
 * MediaMuxer
 * - Executes ffmpeg command using ffmpeg-kit-react-native
 * - Command used: -i {video} -i {audio} -c copy {output}.mp4
 * - No re-encoding (copy streams)
 * - Provides progress callbacks via EventEmitter
 *
 * Important: The underlying ffmpeg binary must support the used codec container. This wrapper assumes
 * the two inputs are compatible for stream copy into mp4.
 */

const emitter = new EventEmitter();

export type MuxProgress = {
  id: string;
  time: number; // processed time in seconds
  percentage?: number;
  message?: string;
};

export async function muxStreams(videoPath: string, audioPath: string) {
  const id = uuidv4();
  try {
    // Prepare output path in app cache. Later caller should move to MediaLibrary if needed.
    const outputFilename = `velox_mux_${id}.mp4`;
    const outputPath = `${FileSystem.cacheDirectory}${outputFilename}`;

    // Build ffmpeg command
    // -y overwrite, -i video -i audio -c copy output.mp4
    const cmd = `-y -i "${videoPath}" -i "${audioPath}" -c copy "${outputPath}"`;

    // Execute with async callback for progress
    await FFmpegKit.executeAsync(
      cmd,
      async (session) => {
        const returnCode = await session.getReturnCode();
        if (returnCode?.isValueSuccess()) {
          emitter.emit('done', { id, outputPath });
        } else {
          const failMsg = `FFmpeg failed with rc=${returnCode}`;
          emitter.emit('error', { id, message: failMsg });
        }
      },
      (log) => {
        // FFmpeg logs
        // optional: parse log to extract time/duration to compute percentage
        emitter.emit('log', { id, message: log.getMessage() });
      },
      (statistics) => {
        // statistics contain time, size, etc.
        const millis = statistics.getTime();
        const timeSec = millis / 1000;
        const payload: MuxProgress = { id, time: timeSec, message: '' };
        emitter.emit('progress', payload);
      }
    );

    return id;
  } catch (e) {
    emitter.emit('error', { id, message: e });
    throw e;
  }
}

export function onMuxProgress(callback: (p: MuxProgress) => void) {
  emitter.addListener('progress', callback);
  return () => emitter.removeListener('progress', callback);
}

export function onMuxDone(callback: (payload: { id: string; outputPath: string }) => void) {
  emitter.addListener('done', callback);
  return () => emitter.removeListener('done', callback);
}

export function onMuxError(callback: (payload: { id: string; message?: string }) => void) {
  emitter.addListener('error', callback);
  return () => emitter.removeListener('error', callback);
}

export function onMuxLog(callback: (payload: { id: string; message?: string }) => void) {
  emitter.addListener('log', callback);
  return () => emitter.removeListener('log', callback);
}