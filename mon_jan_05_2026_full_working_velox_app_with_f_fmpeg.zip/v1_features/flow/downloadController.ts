// features/flow/downloadController.ts
import { EventEmitter } from 'events';
import { startDownloads, onProgress as onDlProgress, onDone as onDlDone, onError as onDlError, stopSession } from '../downloader/downloader';
import { muxStreams, onMuxProgress, onMuxDone, onMuxError, onMuxLog } from '../muxer/mediaMuxer';
import * as MediaLibrary from 'expo-media-library';
import * as FileSystem from 'expo-file-system';
import { startForegroundService, stopForegroundService } from '../../src/native/ForegroundService';

/**
 * Orchestrates:
 * - startForegroundService
 * - downloads (parallel audio + video)
 * - FFmpeg muxing (-c copy)
 * - saving final output to Movies/Velox (MediaLibrary)
 *
 * Emits events via EventEmitter:
 * - status: 'starting' | 'downloading' | 'muxing' | 'saving' | 'done' | 'error'
 * - downloadProgress: { itemId, percentage }
 * - downloadDone: { itemId, localUri, sessionId }
 * - muxProgress: { time }
 * - muxDone: { outputPath }
 * - error: { message }
 */

export type ControllerEvents =
  | 'status'
  | 'downloadProgress'
  | 'downloadDone'
  | 'muxProgress'
  | 'muxDone'
  | 'error';

const emitter = new EventEmitter();

type DownloadInputs = {
  videoUrl: string;
  audioUrl: string;
  suggestedFilename?: string;
};

let currentSessionId: string | null = null;
let downloadItemMap: Record<string, { type: 'video' | 'audio'; localUri?: string }> = {};

function normalizePath(uri: string) {
  // ffmpeg-kit prefers plain filesystem paths; strip file:// if present
  if (!uri) return uri;
  return uri.startsWith('file://') ? uri.replace('file://', '') : uri;
}

export function on(event: ControllerEvents, cb: (...args: any[]) => void) {
  emitter.addListener(event, cb);
  return () => emitter.removeListener(event, cb);
}

export async function runDownloadAndMux(inputs: DownloadInputs) {
  const { videoUrl, audioUrl, suggestedFilename } = inputs;
  emitter.emit('status', 'starting');

  // Start foreground service
  await startForegroundService('Velox', 'Downloading media');
  emitter.emit('status', 'downloading');

  // Prepare download items
  const videoItem = { url: videoUrl, filename: suggestedFilename ? `${suggestedFilename}.mp4` : undefined, type: 'video' as const };
  const audioItem = { url: audioUrl, filename: suggestedFilename ? `${suggestedFilename}.m4a` : undefined, type: 'audio' as const };

  // Listen to progress and done
  const progressUnsub = onDlProgress((p) => {
    emitter.emit('downloadProgress', p);
  });
  const doneUnsub = onDlDone((payload) => {
    const { sessionId, itemId, localUri } = payload as any;
    // store mapping
    downloadItemMap[itemId] = downloadItemMap[itemId] || { type: 'other' as any };
    downloadItemMap[itemId].localUri = localUri;
    emitter.emit('downloadDone', { itemId, localUri, sessionId });

    // Check if we have both audio & video local files (by type)
    const entries = Object.entries(downloadItemMap);
    const videoEntry = entries.find(([, meta]) => meta.type === 'video' && meta.localUri);
    const audioEntry = entries.find(([, meta]) => meta.type === 'audio' && meta.localUri);
    // If both present, proceed to mux
    if (videoEntry && audioEntry) {
      // Stop listening to download events for this session
      // (we keep unsubscribes for cleanup)
      proceedToMux(videoEntry[1].localUri!, audioEntry[1].localUri!, suggestedFilename || `velox_${Date.now()}`);
    }
  });
  const errorUnsub = onDlError((e) => {
    emitter.emit('error', e);
  });

  // Kick off downloads
  try {
    // startDownloads will run downloads in parallel (concurrency set)
    // We need to link the created resumable IDs to known types. Since startDownloads generates item ids internally,
    // we will set item.id to a predictable id so we can map them.
    // So instead call startDownloads with items that include our own ids.

    // Create stable ids
    const videoId = `video-${Date.now()}-v`;
    const audioId = `audio-${Date.now()}-a`;

    // initialize downloadItemMap entries
    downloadItemMap[videoId] = { type: 'video' };
    downloadItemMap[audioId] = { type: 'audio' };

    // Start downloads with our assigned ids
    currentSessionId = await startDownloads(null, [
      { id: videoId, url: videoUrl, filename: videoItem.filename, type: 'video' },
      { id: audioId, url: audioUrl, filename: audioItem.filename, type: 'audio' },
    ]);
  } catch (e) {
    emitter.emit('error', { message: 'Download start failed', error: e });
    // cleanup
    await stopForegroundService();
    return;
  }

  // Helper to proceed to mux after both local files available
  let muxAlreadyStarted = false;
  async function proceedToMux(videoLocalUri: string, audioLocalUri: string, outNameBase: string) {
    if (muxAlreadyStarted) return;
    muxAlreadyStarted = true;

    emitter.emit('status', 'muxing');

    // Normalize paths for ffmpeg
    const vPath = normalizePath(videoLocalUri);
    const aPath = normalizePath(audioLocalUri);
    let muxId: string | null = null;

    // Subscribe to mux events
    const muxProgressUnsub = onMuxProgress((p) => emitter.emit('muxProgress', p));
    const muxDoneUnsub = onMuxDone(async ({ id, outputPath }) => {
      emitter.emit('muxDone', { id, outputPath });
      emitter.emit('status', 'saving');

      try {
        // Save to MediaLibrary (Movies/Velox)
        const cleaned = outputPath.startsWith('file://') ? outputPath.replace('file://', '') : outputPath;
        // Ensure permission
        const { status } = await MediaLibrary.requestPermissionsAsync();
        if (status === 'granted') {
          const asset = await MediaLibrary.createAssetAsync(cleaned);
          const albumName = 'Movies/Velox';
          let album = await MediaLibrary.getAlbumAsync(albumName);
          if (!album) {
            album = await MediaLibrary.createAlbumAsync(albumName, asset, false);
          } else {
            await MediaLibrary.addAssetsToAlbumAsync([asset], album.id, false);
          }
        }
        emitter.emit('status', 'done');
      } catch (e) {
        emitter.emit('error', { message: 'Saving output failed', error: e });
      } finally {
        // stop foreground service
        await stopForegroundService();
        // Cleanup listeners
        muxProgressUnsub();
        muxDoneUnsub();
      }
    });
    const muxErrUnsub = onMuxError(async (p) => {
      emitter.emit('error', p);
      await stopForegroundService();
      muxProgressUnsub();
      muxDoneUnsub();
    });

    try {
      muxId = await muxStreams(vPath, aPath);
    } catch (e) {
      emitter.emit('error', { message: 'Mux start failed', error: e });
      await stopForegroundService();
      muxProgressUnsub();
      muxDoneUnsub();
    }
  }

  // Return a small control API for caller to cancel
  return {
    cancel: async () => {
      try {
        if (currentSessionId) {
          stopSession(currentSessionId);
        }
        await stopForegroundService();
        emitter.emit('status', 'cancelled');
      } catch (e) {
        // ignore
      }
    },
    sessionId: currentSessionId,
    off: () => {
      progressUnsub && progressUnsub();
      doneUnsub && doneUnsub();
      errorUnsub && errorUnsub();
    },
  };
}