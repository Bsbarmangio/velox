// features/flow/DownloadManagerScreen.tsx
import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ProgressBarAndroid, Platform, ProgressViewIOS } from 'react-native';
import { useRoute, RouteProp, useNavigation } from '@react-navigation/native';
import { runDownloadAndMux, on, ControllerEvents } from './downloadController';

type RouteParams = {
  params: {
    videoUrl: string;
    audioUrl: string;
  };
};

export default function DownloadManagerScreen() {
  const route = useRoute() as RouteProp<Record<string, RouteParams>, string>;
  const navigation = useNavigation();
  const { videoUrl, audioUrl } = route.params || { videoUrl: '', audioUrl: '' };

  // progress state
  const [videoProgress, setVideoProgress] = useState(0);
  const [audioProgress, setAudioProgress] = useState(0);
  const [status, setStatus] = useState('idle');
  const [muxTime, setMuxTime] = useState<number | null>(null);
  const controllerRef = useRef<any>(null);

  useEffect(() => {
    let unsubProgress: (() => void) | null = null;
    let unsubDownloadDone: (() => void) | null = null;
    let unsubMuxProgress: (() => void) | null = null;
    let unsubStatus: (() => void) | null = null;
    let unsubError: (() => void) | null = null;
    let unsubMuxDone: (() => void) | null = null;

    // Hook into events via runDownloadAndMux (it uses emitter; we can use the on(...) helper from controller)
    const dl = runDownloadAndMux({ videoUrl, audioUrl });
    controllerRef.current = dl;

    // subscribe to controller emitter
    unsubStatus = on('status', (s: any) => setStatus(s));
    unsubProgress = on('downloadProgress', (p: any) => {
      // p contains: sessionId, itemId, bytesWritten, contentLength, percentage
      const pid = p.itemId as string;
      const pct = p.percentage || 0;
      if (pid.startsWith('video')) {
        setVideoProgress(pct);
      } else if (pid.startsWith('audio')) {
        setAudioProgress(pct);
      } else {
        // unknown; try to detect by payload contentLength or store mapping elsewhere
      }
    });
    unsubDownloadDone = on('downloadDone', (d: any) => {
      // When downloads finish the controller proceeds to mux and emitter status changes.
    });
    unsubMuxProgress = on('muxProgress', (m: any) => {
      setMuxTime(m.time || 0);
    });
    unsubMuxDone = on('muxDone', (p: any) => {
      // Show done and navigate back after a short delay
      setTimeout(() => {
        navigation.navigate('Home' as any);
      }, 900);
    });
    unsubError = on('error', (e: any) => {
      console.warn('DownloadManager error', e);
    });

    return () => {
      // cleanup resets and remove listeners
      try {
        dl && dl.cancel && dl.cancel();
      } catch (e) {}
      unsubStatus && unsubStatus();
      unsubProgress && unsubProgress();
      unsubDownloadDone && unsubDownloadDone();
      unsubMuxProgress && unsubMuxProgress();
      unsubError && unsubError();
      unsubMuxDone && unsubMuxDone();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onCancel = async () => {
    try {
      await controllerRef.current?.cancel();
      navigation.goBack();
    } catch (e) {
      navigation.goBack();
    }
  };

  const renderProgress = (pct: number) => {
    if (Platform.OS === 'android') {
      return <ProgressBarAndroid styleAttr="Horizontal" indeterminate={false} progress={Math.min(1, pct / 100)} color="#00F2EA" />;
    } else {
      return <ProgressViewIOS progress={Math.min(1, pct / 100)} progressTintColor="#00F2EA" />;
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Active Download</Text>

      <View style={styles.row}>
        <Text style={styles.label}>Video</Text>
        <Text style={styles.percent}>{Math.round(videoProgress)}%</Text>
      </View>
      <View style={styles.progress}>{renderProgress(videoProgress)}</View>

      <View style={[styles.row, { marginTop: 12 }]}>
        <Text style={styles.label}>Audio</Text>
        <Text style={styles.percent}>{Math.round(audioProgress)}%</Text>
      </View>
      <View style={styles.progress}>{renderProgress(audioProgress)}</View>

      <View style={{ marginTop: 18 }}>
        <Text style={styles.label}>Status: <Text style={{ color: '#00F2EA', fontWeight: '700' }}>{status}</Text></Text>
        {status === 'muxing' && (
          <Text style={{ color: '#8F9B9A', marginTop: 8 }}>Muxing time: {muxTime ? `${Math.round(muxTime)}s` : '—'}</Text>
        )}
      </View>

      <View style={{ flex: 1 }} />

      <View style={styles.footer}>
        <TouchableOpacity onPress={onCancel} style={styles.cancelBtn}>
          <Text style={{ color: '#00F2EA' }}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B0B0C', padding: 16 },
  title: { color: '#E6F7F6', fontSize: 20, fontWeight: '700', marginTop: 12 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 16 },
  label: { color: '#E6F7F6' },
  percent: { color: '#8F9B9A' },
  progress: { marginTop: 8 },
  footer: { paddingBottom: 24, alignItems: 'center' },
  cancelBtn: { padding: 12, borderRadius: 10, borderWidth: 1, borderColor: '#00F2EA' },
});