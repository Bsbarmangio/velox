// features/downloader/downloader.ts
import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { Platform } from 'react-native';

/**
 * Downloader module
 * - Parallel audio + video downloads
 * - Resumable downloads where supported via FileSystem.createDownloadResumable
 * - Progress reporting via EventEmitter
 *
 * Exports:
 * - startDownloads(sessionId, items) => returns sessionId
 * - onProgress(sessionId, callback)
 * - stopSession(sessionId)
 */

export type DownloadItem = {
  id?: string;
  url: string;
  filename?: string; // suggested filename
  type?: 'video' | 'audio' | 'other';
};

export type ProgressPayload = {
  sessionId: string;
  itemId: string;
  bytesWritten: number;
  contentLength: number;
  percentage: number;
};

const emitter = new EventEmitter();

type SessionData = {
  resumables: { [id: string]: FileSystem.DownloadResumable | null };
  active: boolean;
};

const sessions: { [sessionId: string]: SessionData } = {};

async function _saveToMediaLibrary(localUri: string, type: 'video' | 'audio' | 'other') {
  try {
    const asset = await MediaLibrary.createAssetAsync(localUri);
    const albumName = type === 'audio' ? 'Music/Velox' : 'Movies/Velox';
    // Create or get album - scoped for Android
    let album = await MediaLibrary.getAlbumAsync(albumName);
    if (!album) {
      album = await MediaLibrary.createAlbumAsync(albumName, asset, false);
    } else {
      await MediaLibrary.addAssetsToAlbumAsync([asset], album.id, false);
    }
    return asset;
  } catch (e) {
    console.warn('Failed to save to MediaLibrary', e);
    return null;
  }
}

export async function startDownloads(sessionId: string | null, items: DownloadItem[]) {
  const id = sessionId || uuidv4();
  if (sessions[id] && sessions[id].active) {
    throw new Error('Session already active');
  }

  sessions[id] = { resumables: {}, active: true };

  // Ensure permissions for MediaLibrary
  const { status } = await MediaLibrary.requestPermissionsAsync();
  if (status !== 'granted') {
    console.warn('MediaLibrary permission not granted, saving to app sandbox instead.');
  }

  // Run downloads in parallel but keep a limit (2 at once)
  const concurrency = 2;
  let idx = 0;

  const runNext = async () => {
    if (!sessions[id].active) return;
    if (idx >= items.length) return;
    const item = items[idx++];
    const itemId = item.id || uuidv4();

    try {
      const fileExt = item.filename?.split('.').pop() || 'mp4';
      const localUri = `${FileSystem.cacheDirectory}${itemId}.${fileExt}`;

      // Create resumable where supported
      const downloadResumable = FileSystem.createDownloadResumable(
        item.url,
        localUri,
        {},
        (downloadProgress) => {
          const { totalBytesWritten, totalBytesExpectedToWrite } = downloadProgress;
          const percentage =
            totalBytesExpectedToWrite > 0
              ? (totalBytesWritten / totalBytesExpectedToWrite) * 100
              : 0;
          const payload: ProgressPayload = {
            sessionId: id,
            itemId,
            bytesWritten: totalBytesWritten,
            contentLength: totalBytesExpectedToWrite,
            percentage,
          };
          emitter.emit('progress', payload);
        }
      );

      sessions[id].resumables[itemId] = downloadResumable;

      const result = await downloadResumable.downloadAsync();

      // Save to MediaLibrary (ensures Android MediaStore indexing)
      if (status === 'granted') {
        await _saveToMediaLibrary(result.uri, item.type || 'other');
      }

      emitter.emit('done', { sessionId: id, itemId, localUri: result.uri });
    } catch (e) {
      console.warn('Download failed for item', item, e);
      emitter.emit('error', { sessionId: id, itemId, error: e });
    } finally {
      // start next
      await runNext();
    }
  };

  // start initial batch
  const runners = [];
  for (let i = 0; i < concurrency; i++) {
    runners.push(runNext());
  }

  await Promise.all(runners);

  // Session complete
  sessions[id].active = false;
  return id;
}

export function onProgress(callback: (p: ProgressPayload) => void) {
  emitter.addListener('progress', callback);
  return () => emitter.removeListener('progress', callback);
}

export function onDone(callback: (payload: { sessionId: string; itemId: string; localUri: string }) => void) {
  emitter.addListener('done', callback);
  return () => emitter.removeListener('done', callback);
}

export function onError(callback: (payload: { sessionId: string; itemId: string; error: any }) => void) {
  emitter.addListener('error', callback);
  return () => emitter.removeListener('error', callback);
}

export function stopSession(sessionId: string) {
  const s = sessions[sessionId];
  if (!s) return;
  s.active = false;
  // pause/resume not provided directly in expo FileSystem - cancel any resumables
  Object.values(s.resumables).forEach((r) => {
    try {
      r && r.pauseAsync && r.pauseAsync();
    } catch (e) {}
  });
  emitter.emit('stopped', { sessionId });
}