// features/home/BentoHomeUI.tsx
import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Platform,
  Animated as RNAnimated,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Clipboard from 'expo-clipboard';
import { runOnJS } from 'react-native-reanimated';
import Animated, { useSharedValue, withTiming, useAnimatedStyle, Easing } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');

function FrostedURLBar({ value, onChange, onSubmit }: { value: string; onChange: (v: string) => void; onSubmit: () => void }) {
  return (
    <View style={styles.frostedContainer}>
      <TextInput
        accessibilityLabel="URL input"
        placeholder="Enter Video Stream URL or paste from clipboard"
        placeholderTextColor="#8F9B9A"
        style={styles.urlInput}
        value={value}
        onChangeText={onChange}
        onSubmitEditing={onSubmit}
        returnKeyType="go"
      />
      <TouchableOpacity style={styles.pasteButton} onPress={async () => {
        const text = await Clipboard.getStringAsync();
        onChange(text);
      }}>
        <Ionicons name="clipboard-outline" size={20} color="#00F2EA" />
      </TouchableOpacity>
    </View>
  );
}

export default function BentoHomeUI() {
  const insets = useSafeAreaInsets();
  const [url, setUrl] = useState('');
  const [clipboardDetected, setClipboardDetected] = useState(false);
  const pulse = useSharedValue(1);

  useEffect(() => {
    // detect URL-like strings on clipboard on mount
    (async () => {
      const text = await Clipboard.getStringAsync();
      if (text && text.length > 0 && text.includes('http')) {
        setClipboardDetected(true);
      } else {
        setClipboardDetected(false);
      }
    })();
  }, []);

  useEffect(() => {
    // pulsing animation for active download button
    pulse.value = withTiming(1.08, {
      duration: 800,
      easing: Easing.inOut(Easing.cubic),
    });
  }, [pulse]);

  const pulseStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulse.value }],
    shadowColor: '#00F2EA',
    shadowOpacity: 0.25,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  }));

  return (
    <View style={[styles.container, { paddingTop: insets.top + 12 }]}>
      <View style={styles.top}>
        <FrostedURLBar value={url} onChange={setUrl} onSubmit={() => { /* trigger detection */ }} />
      </View>

      <View style={styles.middle}>
        <View style={styles.bentoRow}>
          <TouchableOpacity style={styles.card}>
            <Text style={styles.cardTitle}>Recent Downloads</Text>
            <Text style={styles.cardSub}>Private • Fast</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.card}>
            <Text style={styles.cardTitle}>Storage Stats</Text>
            <Text style={styles.cardSub}>Available • 12.3 GB</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.bentoRow}>
          <TouchableOpacity style={styles.card}>
            <Text style={styles.cardTitle}>Private Vault</Text>
            <Text style={styles.cardSub}>AES-256 • Biometric</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.card}>
            <Text style={styles.cardTitle}>Browser</Text>
            <Text style={styles.cardSub}>Incognito Mode</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.bottom}>
        {clipboardDetected && (
          <Animated.View entering={undefined} exiting={undefined} style={styles.clipboardCard}>
            <Text style={styles.clipboardTitle}>Smart Clipboard</Text>
            <Text style={styles.clipboardText} numberOfLines={1}>A Video Stream URL was detected in your clipboard</Text>
            <TouchableOpacity style={styles.actionButton}>
              <Animated.View style={[{ padding: 12, borderRadius: 10, backgroundColor: '#00F2EA' }, pulseStyle]}>
                <Text style={{ color: '#021212', fontWeight: '700' }}>Download</Text>
              </Animated.View>
            </TouchableOpacity>
          </Animated.View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0B0B0C',
    paddingHorizontal: 16,
    justifyContent: 'space-between',
  },
  top: {
    marginTop: 8,
  },
  frostedContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#12121380',
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 10,
    backdropFilter: 'blur(8px)' as any,
  },
  urlInput: {
    flex: 1,
    color: '#E6F7F6',
    fontSize: 16,
  },
  pasteButton: {
    marginLeft: 8,
    padding: 6,
    borderRadius: 8,
  },
  middle: {
    marginTop: 18,
  },
  bentoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  card: {
    width: (width - 48) / 2,
    height: 140,
    backgroundColor: '#0F0F10',
    borderRadius: 14,
    padding: 12,
    justifyContent: 'space-between',
    shadowColor: '#00F2EA',
    shadowOpacity: 0.06,
    shadowRadius: 10,
  },
  cardTitle: {
    color: '#E6F7F6',
    fontWeight: '700',
    fontSize: 16,
  },
  cardSub: {
    color: '#8F9B9A',
    fontSize: 12,
  },
  bottom: {
    marginBottom: 24,
  },
  clipboardCard: {
    backgroundColor: '#0F1313',
    borderRadius: 14,
    padding: 16,
  },
  clipboardTitle: {
    color: '#00F2EA',
    fontWeight: '700',
    marginBottom: 6,
  },
  clipboardText: {
    color: '#E6F7F6',
    marginBottom: 12,
  },
  actionButton: {
    alignSelf: 'flex-end',
  },
});