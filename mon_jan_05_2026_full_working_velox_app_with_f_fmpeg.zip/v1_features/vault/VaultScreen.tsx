// features/vault/VaultScreen.tsx
import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList } from 'react-native';
import * as FileSystem from 'expo-file-system';
import { encryptFileToVault, listVaultFiles, decryptVaultFile } from './vault';
import * as DocumentPicker from 'expo-document-picker';
import * as MediaLibrary from 'expo-media-library';

export default function VaultScreen() {
  const [files, setFiles] = useState<Array<{ id: string; name: string }>>([]);

  useEffect(() => {
    refresh();
  }, []);

  async function refresh() {
    const l = await listVaultFiles();
    setFiles(l);
  }

  async function addFile() {
    const res = await DocumentPicker.getDocumentAsync({});
    if (res.type === 'success' && res.uri) {
      await encryptFileToVault(res.uri);
      await refresh();
    }
  }

  async function exportFile(id: string) {
    try {
      const path = await decryptVaultFile(id);
      // Save to media library or present share sheet.
      const info = await MediaLibrary.requestPermissionsAsync();
      if (info.status === 'granted') {
        await MediaLibrary.saveToLibraryAsync(path);
      }
    } catch (e) {
      console.warn(e);
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Private Vault</Text>
        <TouchableOpacity style={styles.addBtn} onPress={addFile}>
          <Text style={{ color: '#021212', fontWeight: '700' }}>Add</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={files}
        keyExtractor={(i) => i.id}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <Text style={{ color: '#E6F7F6' }}>{item.name}</Text>
            <TouchableOpacity onPress={() => exportFile(item.id)} style={styles.rowBtn}>
              <Text style={{ color: '#00F2EA' }}>Export</Text>
            </TouchableOpacity>
          </View>
        )}
        ListEmptyComponent={<Text style={{ color: '#8F9B9A' }}>No files in vault</Text>}
        contentContainerStyle={{ padding: 16 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B0B0C' },
  header: { padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { color: '#E6F7F6', fontSize: 20, fontWeight: '700' },
  addBtn: { backgroundColor: '#00F2EA', padding: 10, borderRadius: 8 },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12, borderBottomColor: '#111', borderBottomWidth: 1 },
  rowBtn: { paddingHorizontal: 12 },
});