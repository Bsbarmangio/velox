// features/browser/BrowserScreen.tsx
import React, { useCallback, useState } from 'react';
import { View, StyleSheet, Text, TouchableOpacity, TextInput } from 'react-native';
import IncognitoWebView from './IncognitoWebView';
import { useNavigation } from '@react-navigation/native';

export default function BrowserScreen() {
  const [url, setUrl] = useState('https://example.com');
  const [detected, setDetected] = useState<string | null>(null);
  const navigation = useNavigation();

  const onStreamDetected = useCallback((streamUrl: string) => {
    setDetected(streamUrl);
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={{ color: '#00F2EA' }}>Close</Text>
        </TouchableOpacity>
        <TextInput
          value={url}
          onChangeText={setUrl}
          style={styles.input}
          placeholder="Enter URL"
          placeholderTextColor="#8F9B9A"
        />
      </View>

      <IncognitoWebView initialUrl={url} onStreamDetected={onStreamDetected} />

      {detected && (
        <View style={styles.detectCard}>
          <Text style={{ color: '#E6F7F6', fontWeight: '700' }}>Detected Video Stream</Text>
          <Text style={{ color: '#8F9B9A' }} numberOfLines={1}>{detected}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B0B0C' },
  topBar: {
    paddingTop: 12,
    paddingHorizontal: 12,
    paddingBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#0B0B0C',
  },
  input: {
    flex: 1,
    marginLeft: 12,
    height: 40,
    backgroundColor: '#12121380',
    color: '#E6F7F6',
    borderRadius: 8,
    paddingHorizontal: 10,
  },
  detectCard: {
    padding: 12,
    margin: 12,
    backgroundColor: '#0F0F10',
    borderRadius: 12,
  },
});