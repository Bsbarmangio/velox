// plugins/withFFmpeg.ts
import {
  ConfigPlugin,
  withAndroidManifest,
  AndroidConfig,
  withAppBuildGradle,
  withProjectBuildGradle,
  withDangerousMod,
} from '@expo/config-plugins';
import fs from 'fs';
import path from 'path';

const { AndroidManifest } = AndroidConfig;

const withFFmpeg: ConfigPlugin = (config) => {
  // 1) AndroidManifest: permissions + service
  config = withAndroidManifest(config, (config) => {
    const manifest = config.modResults;
    manifest.manifest['uses-permission'] = manifest.manifest['uses-permission'] || [];
    const perms = [
      'android.permission.FOREGROUND_SERVICE',
      'android.permission.WAKE_LOCK',
      'android.permission.POST_NOTIFICATIONS',
      'android.permission.READ_EXTERNAL_STORAGE',
      'android.permission.WRITE_EXTERNAL_STORAGE',
    ];
    const existing = new Set(
      (manifest.manifest['uses-permission'] as any[]).map((p) => p.$['android:name'])
    );
    perms.forEach((p) => {
      if (!existing.has(p)) {
        (manifest.manifest['uses-permission'] as any[]).push({
          $: { 'android:name': p },
        });
      }
    });

    const application = manifest.manifest.application[0];
    application.service = application.service || [];
    const serviceExists = (application.service as any[]).some(
      (s) => s.$['android:name'] === 'com.velox.VeloxForegroundService'
    );
    if (!serviceExists) {
      (application.service as any[]).push({
        $: {
          'android:name': 'com.velox.VeloxForegroundService',
          'android:enabled': 'true',
          'android:exported': 'false',
        },
      });
    }

    return config;
  });

  // 2) app/build.gradle: add ffmpeg-kit and abiFilters
  config = withAppBuildGradle(config, (config) => {
    let gradle = config.modResults.contents as string;
    const ffmpegDep = `implementation 'com.arthenica:ffmpeg-kit-full:4.5.LTS'`;
    if (!gradle.includes('com.arthenica:ffmpeg-kit-full')) {
      gradle = gradle.replace(/dependencies\s*{/, (m) => `${m}\n    ${ffmpegDep}`);
    }

    if (!gradle.includes('ndk { abiFilters')) {
      gradle = gradle.replace(
        /defaultConfig\s*\{/,
        `defaultConfig {\n            ndk { abiFilters "armeabi-v7a", "arm64-v8a" }\n            multiDexEnabled true\n`
      );
    }

    config.modResults.contents = gradle;
    return config;
  });

  // 3) project-level build.gradle ensure mavenCentral
  config = withProjectBuildGradle(config, (config) => {
    let contents = config.modResults.contents as string;
    if (!contents.includes('mavenCentral()')) {
      contents = contents.replace(/repositories\s*{\s*/, (m) => `${m}\n        mavenCentral()\n`);
    }
    config.modResults.contents = contents;
    return config;
  });

  // 4) Dangerously write Kotlin native files into android source (for prebuild)
  config = withDangerousMod(config, [
    'android',
    async (modConfig) => {
      const projectRoot = modConfig.modRequest.projectRoot;
      const baseKotlinDir = path.join(
        projectRoot,
        'android',
        'app',
        'src',
        'main',
        'kotlin',
        'com',
        'velox'
      );
      fs.mkdirSync(baseKotlinDir, { recursive: true });

      // VeloxForegroundService.kt
      const servicePath = path.join(baseKotlinDir, 'VeloxForegroundService.kt');
      const serviceContents = `package com.velox

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class VeloxForegroundService : Service() {
    private val CHANNEL_ID = "velox_foreground_channel"
    private val NOTIF_ID = 4242

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val title = intent?.getStringExtra("title") ?: "Velox"
            val body = intent?.getStringExtra("body") ?: "Processing media"
            val progressExtra = if (intent != null && intent.hasExtra("progress")) intent.getFloatExtra("progress", -1f) else -1f
            val progress: Int? = if (progressExtra >= 0f) Math.round(progressExtra) else null

            val builder = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)

            if (progress != null) {
                val bounded = when {
                    progress < 0 -> 0
                    progress > 100 -> 100
                    else -> progress
                }
                builder.setProgress(100, bounded, false)
                builder.setContentText("$body • $bounded%")
            } else {
                builder.setProgress(0, 0, false)
            }

            val notification: Notification = builder.build()
            startForeground(NOTIF_ID, notification)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopForeground(true)
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Velox background",
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(channel)
        }
    }
}
`;
      fs.writeFileSync(servicePath, serviceContents, 'utf8');

      // VeloxForegroundServiceModule.kt
      const modulePath = path.join(baseKotlinDir, 'VeloxForegroundServiceModule.kt');
      const moduleContents = `package com.velox

import android.content.Intent
import android.os.Build
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod

class VeloxForegroundServiceModule(reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    override fun getName(): String {
        return "VeloxForegroundServiceModule"
    }

    @ReactMethod
    fun startService(title: String?, body: String?, promise: Promise) {
        try {
            val ctx = reactApplicationContext
            val intent = Intent(ctx, VeloxForegroundService::class.java)
            intent.putExtra("title", title ?: "Velox")
            intent.putExtra("body", body ?: "Processing media")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(intent)
            } else {
                ctx.startService(intent)
            }
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("start_error", e)
        }
    }

    @ReactMethod
    fun stopService(promise: Promise) {
        try {
            val ctx = reactApplicationContext
            val intent = Intent(ctx, VeloxForegroundService::class.java)
            ctx.stopService(intent)
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("stop_error", e)
        }
    }

    @ReactMethod
    fun updateNotification(title: String?, body: String?, progress: Double?, promise: Promise) {
        try {
            val ctx = reactApplicationContext
            val intent = Intent(ctx, VeloxForegroundService::class.java)
            intent.action = "com.velox.ACTION_UPDATE_NOTIFICATION"
            if (title != null) intent.putExtra("title", title)
            if (body != null) intent.putExtra("body", body)
            if (progress != null) {
                intent.putExtra("progress", progress.toFloat())
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(intent)
            } else {
                ctx.startService(intent)
            }
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("update_error", e)
        }
    }
}
`;
      fs.writeFileSync(modulePath, moduleContents, 'utf8');

      // VeloxPackage.kt
      const packagePath = path.join(baseKotlinDir, 'VeloxPackage.kt');
      const packageContents = `package com.velox

import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ViewManager

class VeloxPackage : ReactPackage {
    override fun createNativeModules(reactContext: ReactApplicationContext): List<NativeModule> {
        return listOf(VeloxForegroundServiceModule(reactContext))
    }

    override fun createViewManagers(reactContext: ReactApplicationContext): List<ViewManager<*, *>> {
        return emptyList()
    }
}
`;
      fs.writeFileSync(packagePath, packageContents, 'utf8');

      // Attempt to patch MainApplication if found
      const javaPath = path.join(projectRoot, 'android', 'app', 'src', 'main', 'java');
      function findMainApplication(dir: string): string | null {
        const entries = fs.readdirSync(dir);
        for (const e of entries) {
          const full = path.join(dir, e);
          const stat = fs.statSync(full);
          if (stat.isDirectory()) {
            const found = findMainApplication(full);
            if (found) return found;
          } else if (stat.isFile() && (e === 'MainApplication.java' || e === 'MainApplication.kt')) {
            return full;
          }
        }
        return null;
      }

      const mainAppPath = findMainApplication(javaPath);
      if (mainAppPath) {
        let mainApp = fs.readFileSync(mainAppPath, 'utf8');
        if (!mainApp.includes('new com.velox.VeloxPackage')) {
          if (mainApp.includes('new PackageList')) {
            mainApp = mainApp.replace(
              /(List<ReactPackage> packages = new PackageList\\([^)]+\\)\\.getPackages\\(\\);\\s*)/,
              `$1\n        // Velox: add VeloxPackage to register the foreground service native module\n        packages.add(new com.velox.VeloxPackage());\n`
            );
            fs.writeFileSync(mainAppPath, mainApp, 'utf8');
          } else {
            mainApp = mainApp.replace(/(return packages;\\s*)/, `        packages.add(new com.velox.VeloxPackage());\n        return packages;\n`);
            fs.writeFileSync(mainAppPath, mainApp, 'utf8');
          }
        }
      }

      return modConfig;
    },
  ]);

  return config;
};

export default withFFmpeg;