package com.velox

import android.content.Intent
import android.os.Build
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod

/**
 * Native module exposing:
 * - startService(title, body)
 * - stopService()
 * - updateNotification(title, body, progress)
 *
 * updateNotification sends an intent with action "com.velox.ACTION_UPDATE_NOTIFICATION" with extras:
 * - title (String)
 * - body (String)
 * - progress (Float) [0..100]
 *
 * The service reacts to the intent and updates its notification.
 */
class VeloxForegroundServiceModule(reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    override fun getName(): String {
        return "VeloxForegroundServiceModule"
    }

    @ReactMethod
    fun startService(title: String?, body: String?, promise: Promise) {
        try {
            val ctx = reactApplicationContext
            val intent = Intent(ctx, VeloxForegroundService::class.java)
            intent.putExtra("title", title ?: "Velox")
            intent.putExtra("body", body ?: "Processing media")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(intent)
            } else {
                ctx.startService(intent)
            }
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("start_error", e)
        }
    }

    @ReactMethod
    fun stopService(promise: Promise) {
        try {
            val ctx = reactApplicationContext
            val intent = Intent(ctx, VeloxForegroundService::class.java)
            ctx.stopService(intent)
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("stop_error", e)
        }
    }

    @ReactMethod
    fun updateNotification(title: String?, body: String?, progress: Double?, promise: Promise) {
        try {
            val ctx = reactApplicationContext
            val intent = Intent(ctx, VeloxForegroundService::class.java)
            // Use an explicit action to indicate update intent; service reads extras regardless of action
            intent.action = "com.velox.ACTION_UPDATE_NOTIFICATION"
            if (title != null) intent.putExtra("title", title)
            if (body != null) intent.putExtra("body", body)
            if (progress != null) {
                // pass as float
                intent.putExtra("progress", progress.toFloat())
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(intent)
            } else {
                ctx.startService(intent)
            }
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("update_error", e)
        }
    }
}