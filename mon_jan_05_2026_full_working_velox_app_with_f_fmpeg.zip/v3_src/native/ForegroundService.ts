// src/native/ForegroundService.ts
import { NativeModules, Platform } from 'react-native';

const { VeloxForegroundServiceModule } = NativeModules;

export async function startForegroundService(title = 'Velox', body = 'Processing media') {
  if (Platform.OS !== 'android' || !VeloxForegroundServiceModule) return false;
  try {
    await VeloxForegroundServiceModule.startService(title, body);
    return true;
  } catch (e) {
    console.warn('startForegroundService failed', e);
    return false;
  }
}

export async function stopForegroundService() {
  if (Platform.OS !== 'android' || !VeloxForegroundServiceModule) return false;
  try {
    await VeloxForegroundServiceModule.stopService();
    return true;
  } catch (e) {
    console.warn('stopForegroundService failed', e);
    return false;
  }
}

export async function updateNotification(title?: string, body?: string, progress?: number) {
  if (Platform.OS !== 'android' || !VeloxForegroundServiceModule) return false;
  try {
    const p = typeof progress === 'number' && isFinite(progress) ? Math.max(0, Math.min(100, progress)) : null;
    await VeloxForegroundServiceModule.updateNotification(title || null, body || null, p);
    return true;
  } catch (e) {
    console.warn('updateNotification failed', e);
    return false;
  }
}