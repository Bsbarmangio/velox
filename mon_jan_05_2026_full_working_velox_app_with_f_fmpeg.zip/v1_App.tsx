// App.tsx
import React, { useEffect } from 'react';
import { LogBox, StatusBar, Platform } from 'react-native';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import BentoHomeUI from './features/home/BentoHomeUI';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { QueryClient, QueryClientProvider } from 'react-query';
import * as SecureStore from 'expo-secure-store';
import * as Localization from 'expo-localization';

// Firebase placeholders
import { initializeApp } from 'firebase/app';
import { getAnalytics } from 'firebase/analytics';
import { getCrashlytics } from 'firebase/crashlytics';
import { getRemoteConfig, fetchAndActivate } from 'firebase/remote-config';

// App theme variables
const VeloxTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: '#0B0B0C',
    card: '#0F0F10',
    primary: '#00F2EA',
    text: '#E6F7F6',
  },
};

const Stack = createNativeStackNavigator();
const queryClient = new QueryClient();

LogBox.ignoreAllLogs(true);

export default function App() {
  useEffect(() => {
    // Initialize Firebase (Analytics + Crashlytics + Remote Config)
    // NOTE: Replace with your actual Firebase config before building.
    try {
      const firebaseConfig = {
        apiKey: 'REPLACE_ME',
        authDomain: 'REPLACE_ME',
        projectId: 'REPLACE_ME',
        storageBucket: 'REPLACE_ME',
        messagingSenderId: 'REPLACE_ME',
        appId: 'REPLACE_ME',
        measurementId: 'REPLACE_ME',
      };

      const app = initializeApp(firebaseConfig);

      // Analytics safe init - web-only may throw in Node env; guard platform checks
      if (Platform.OS !== 'web') {
        try {
          getAnalytics(app);
        } catch (err) {
          // optional analytics failure is non-fatal
          console.warn('Analytics init failed', err);
        }
      }

      try {
        getCrashlytics(app);
      } catch (e) {
        console.warn('Crashlytics init skipped/failed', e);
      }

      try {
        const rc = getRemoteConfig(app);
        rc.settings = { minimumFetchIntervalMillis: 3600000 }; // 1 hour
        fetchAndActivate(rc).catch(() => {});
      } catch (e) {
        // remote config optional
      }
    } catch (e) {
      console.warn('Firebase init skipped', e);
    }
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <QueryClientProvider client={queryClient}>
        <NavigationContainer theme={VeloxTheme}>
          <StatusBar barStyle="light-content" backgroundColor="#0B0B0C" />
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Home" component={BentoHomeUI} />
          </Stack.Navigator>
        </NavigationContainer>
      </QueryClientProvider>
    </GestureHandlerRootView>
  );
}