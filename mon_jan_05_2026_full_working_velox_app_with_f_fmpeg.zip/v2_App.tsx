// App.tsx
import React, { useEffect } from 'react';
import { StatusBar, Platform } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import BentoHomeUI from './features/home/BentoHomeUI';
import BrowserScreen from './features/browser/BrowserScreen';
import VaultScreen from './features/vault/VaultScreen';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { QueryClient, QueryClientProvider } from 'react-query';

const Stack = createNativeStackNavigator();
const queryClient = new QueryClient();

export default function App() {
  useEffect(() => {
    // any app startup tasks (analytics init placeholder) can be performed here
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <QueryClientProvider client={queryClient}>
        <NavigationContainer>
          <StatusBar barStyle="light-content" backgroundColor="#0B0B0C" />
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Home" component={BentoHomeUI} />
            <Stack.Screen name="Browser" component={BrowserScreen} />
            <Stack.Screen name="Vault" component={VaultScreen} />
          </Stack.Navigator>
        </NavigationContainer>
      </QueryClientProvider>
    </GestureHandlerRootView>
  );
}