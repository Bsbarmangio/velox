// app.config.ts
import { ExpoConfig, ConfigContext, withPlugins } from '@expo/config-plugins';
import withFFmpeg from './plugins/withFFmpeg';

/**
 * Register the custom FFmpeg + Foreground Service plugin.
 * - Adds Android permissions to AndroidManifest
 * - Injects ffmpeg-kit dependency and ndk abiFilters
 * - Writes Kotlin native files (ForegroundService + Native Module + Package)
 *
 * Run with: expo prebuild
 */
export default ({ config }: ConfigContext): ExpoConfig => {
  return withPlugins(config, [withFFmpeg]) as ExpoConfig;
};