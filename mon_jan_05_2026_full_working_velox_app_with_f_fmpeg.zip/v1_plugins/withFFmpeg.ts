// plugins/withFFmpeg.ts
import {
  ConfigContext,
  withAndroidManifest,
  AndroidConfig,
  withAppBuildGradle,
  withProjectBuildGradle,
  withDangerousMod,
  IOSConfig,
  withPlugins,
} from '@expo/config-plugins';
import fs from 'fs';
import path from 'path';

const { AndroidManifest } = AndroidConfig;

/**
 * Custom Expo config plugin that:
 * - Adds Android permissions including FOREGROUND_SERVICE and notification permission.
 * - Adds a Foreground Service declaration into AndroidManifest.
 * - Adds ffmpeg-kit Gradle dependencies and abiFilters for armeabi-v7a and arm64-v8a.
 * - Writes a small Kotlin ForegroundService implementation into the prebuild android folder
 *
 * This plugin runs during expo prebuild and modifies Android native files.
 */
const withFFmpeg = (config: any) => {
  // 1) Add Android permissions and service to AndroidManifest
  config = withAndroidManifest(config, async (config) => {
    const androidManifest = config.modResults;

    // Ensure uses-permission entries exist
    const permissions = [
      'android.permission.FOREGROUND_SERVICE',
      'android.permission.WAKE_LOCK',
      // Android 13+ notification permission
      'android.permission.POST_NOTIFICATIONS',
      // Scoped storage read/write (we use MediaStore via MediaLibrary)
      'android.permission.READ_EXTERNAL_STORAGE',
      'android.permission.WRITE_EXTERNAL_STORAGE',
    ];

    androidManifest.manifest['uses-permission'] = androidManifest.manifest['uses-permission'] || [];

    const existing = new Set(
      (androidManifest.manifest['uses-permission'] as any[]).map((p) => p.$['android:name'])
    );

    permissions.forEach((p) => {
      if (!existing.has(p)) {
        (androidManifest.manifest['uses-permission'] as any[]).push({
          $: {
            'android:name': p,
          },
        });
      }
    });

    // Add service declaration for the foreground service
    const application = androidManifest.manifest.application[0];

    application.service = application.service || [];

    const serviceExists = (application.service as any[]).some(
      (s) => s.$['android:name'] === 'com.velox.VeloxForegroundService'
    );

    if (!serviceExists) {
      (application.service as any[]).push({
        $: {
          'android:name': 'com.velox.VeloxForegroundService',
          'android:enabled': 'true',
          'android:exported': 'false',
        },
      });
    }

    return config;
  });

  // 2) Modify app-level build.gradle (app/build.gradle) to add ffmpeg-kit dependency and abiFilters
  config = withAppBuildGradle(config, (config) => {
    let buildGradle = config.modResults.contents as string;

    // Add ffmpeg-kit dependency (use the full package to include muxing binaries)
    const ffmpegDependency = `    implementation 'com.arthenica:ffmpeg-kit-full:4.5.LTS'`;

    if (!buildGradle.includes('com.arthenica:ffmpeg-kit-full')) {
      // Insert dependency into dependencies block
      buildGradle = buildGradle.replace(
        /dependencies\s*{/,
        (match) => `${match}\n${ffmpegDependency}`
      );
    }

    // Ensure abiFilters for armeabi-v7a and arm64-v8a in defaultConfig or packagingOptions
    if (!buildGradle.includes('abiFilters')) {
      // try to add into defaultConfig
      if (buildGradle.includes('defaultConfig {')) {
        buildGradle = buildGradle.replace(
          /defaultConfig\s*\{/,
          `defaultConfig {\n            ndk { abiFilters "armeabi-v7a", "arm64-v8a" }\n            multiDexEnabled true\n`
        );
      }
    }

    config.modResults.contents = buildGradle;
    return config;
  });

  // 3) Modify project-level build.gradle to ensure maven repo is present
  config = withProjectBuildGradle(config, (config) => {
    let contents = config.modResults.contents as string;

    // Ensure mavenCentral() and jcenter() are available (ffmpeg-kit publishes to mavenCentral)
    if (!contents.includes('mavenCentral()')) {
      contents = contents.replace(
        /allprojects\s*{([^}]*)repositories\s*\{/s,
        (match, p1) => match // leave as-is if pattern not clear
      );
      // fallback: ensure mavenCentral in repositories block near top
      contents = contents.replace(
        /repositories\s*{\s*/,
        (match) => `${match}\n        mavenCentral()`
      );
    }

    config.modResults.contents = contents;
    return config;
  });

  // 4) Write a small Kotlin ForegroundService into android/app/src/main/kotlin/com/velox
  config = withDangerousMod(config, [
    'android',
    async (config) => {
      const projectRoot = config.modRequest.projectRoot;
      const targetDir = path.join(
        projectRoot,
        'android',
        'app',
        'src',
        'main',
        'kotlin',
        'com',
        'velox'
      );

      // Ensure directory
      fs.mkdirSync(targetDir, { recursive: true });

      const kotlinFile = path.join(targetDir, 'VeloxForegroundService.kt');

      // Kotlin Foreground Service implementation
      const kotlinContents = `package com.velox

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

// Minimal foreground service to ensure long-running downloads / muxing survive
class VeloxForegroundService : Service() {
    private val CHANNEL_ID = "velox_foreground_channel"
    private val NOTIF_ID = 4242

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val title = intent?.getStringExtra("title") ?: "Velox"
        val body = intent?.getStringExtra("body") ?: "Processing media"

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIF_ID, notification)
        // Service will remain until stopped explicitly
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        stopForeground(true)
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Velox background",
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(channel)
        }
    }
}
`;

      fs.writeFileSync(kotlinFile, kotlinContents, { encoding: 'utf8' });

      return config;
    },
  ]);

  return config;
};

export default withFFmpeg;