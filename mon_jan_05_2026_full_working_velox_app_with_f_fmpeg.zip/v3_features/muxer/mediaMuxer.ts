// features/muxer/mediaMuxer.ts
import { FFmpegKit } from 'ffmpeg-kit-react-native';
import { EventEmitter } from 'events';
import * as FileSystem from 'expo-file-system';
import { v4 as uuidv4 } from 'uuid';

const emitter = new EventEmitter();

export type MuxProgress = { id: string; time: number; message?: string };

export async function muxStreams(videoPath: string, audioPath: string) {
  const id = uuidv4();
  const outputPath = `${FileSystem.cacheDirectory}velox_mux_${id}.mp4`;
  const cmd = `-y -i "${videoPath}" -i "${audioPath}" -c copy "${outputPath}"`;

  try {
    await FFmpegKit.executeAsync(
      cmd,
      async (session) => {
        const rc = await session.getReturnCode();
        if (rc && rc.isValueSuccess()) {
          emitter.emit('done', { id, outputPath });
        } else {
          emitter.emit('error', { id, message: 'FFmpeg failed: ' + rc });
        }
      },
      (log) => {
        emitter.emit('log', { id, message: log.getMessage() });
      },
      (statistics) => {
        const time = statistics.getTime() / 1000;
        emitter.emit('progress', { id, time });
      }
    );
    return id;
  } catch (e) {
    emitter.emit('error', { id, message: (e as Error).message });
    throw e;
  }
}

export function onMuxProgress(cb: (p: MuxProgress) => void) {
  emitter.addListener('progress', cb);
  return () => emitter.removeListener('progress', cb);
}
export function onMuxDone(cb: (p: { id: string; outputPath: string }) => void) {
  emitter.addListener('done', cb);
  return () => emitter.removeListener('done', cb);
}
export function onMuxError(cb: (p: { id: string; message?: string }) => void) {
  emitter.addListener('error', cb);
  return () => emitter.removeListener('error', cb);
}
export function onMuxLog(cb: (p: { id: string; message?: string }) => void) {
  emitter.addListener('log', cb);
  return () => emitter.removeListener('log', cb);
}