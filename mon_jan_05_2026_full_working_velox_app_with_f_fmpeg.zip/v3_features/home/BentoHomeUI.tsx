// features/home/BentoHomeUI.tsx
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions, TextInput } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Clipboard from 'expo-clipboard';
import Animated, { useSharedValue, useAnimatedStyle, withTiming, Easing } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

const { width } = Dimensions.get('window');

export default function BentoHomeUI() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const [url, setUrl] = useState('');
  const [clipboardDetected, setClipboardDetected] = useState<string | null>(null);
  const pulse = useSharedValue(1);

  useEffect(() => {
    (async () => {
      const txt = await Clipboard.getStringAsync();
      if (txt && txt.includes('http')) {
        setClipboardDetected(txt);
      } else {
        setClipboardDetected(null);
      }
    })();
  }, []);

  useEffect(() => {
    pulse.value = withTiming(1.06, { duration: 800, easing: Easing.inOut(Easing.cubic) });
  }, [pulse]);

  const pulseStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulse.value }],
  }));

  return (
    <View style={[styles.container, { paddingTop: insets.top + 12 }]}>
      <View style={styles.top}>
        <View style={styles.frostedContainer}>
          <TextInput
            placeholder="Enter Video Stream URL or open browser"
            placeholderTextColor="#8F9B9A"
            style={styles.urlInput}
            value={url}
            onChangeText={setUrl}
          />
          <TouchableOpacity style={styles.pasteButton} onPress={() => navigation.navigate('Browser' as any)}>
            <Ionicons name="globe-outline" size={20} color="#00F2EA" />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.middle}>
        <View style={styles.bentoRow}>
          <TouchableOpacity style={styles.card}>
            <Text style={styles.cardTitle}>Recent Downloads</Text>
            <Text style={styles.cardSub}>Private • Fast</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.card}>
            <Text style={styles.cardTitle}>Storage Stats</Text>
            <Text style={styles.cardSub}>Available • 12.3 GB</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.bentoRow}>
          <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('Vault' as any)}>
            <Text style={styles.cardTitle}>Private Vault</Text>
            <Text style={styles.cardSub}>AES-256 • Biometric</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('Browser' as any)}>
            <Text style={styles.cardTitle}>Browser</Text>
            <Text style={styles.cardSub}>Incognito Mode</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.bottom}>
        {clipboardDetected && (
          <Animated.View style={[styles.clipboardCard, pulseStyle]}>
            <Text style={styles.clipboardTitle}>Smart Clipboard</Text>
            <Text style={styles.clipboardText} numberOfLines={1}>
              A Video Stream URL was detected in your clipboard
            </Text>
            <View style={{ flexDirection: 'row', gap: 12 }}>
              <TouchableOpacity style={styles.smallButton}>
                <Text style={{ color: '#021212', fontWeight: '700' }}>Download</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.smallButtonOutline} onPress={() => setClipboardDetected(null)}>
                <Text style={{ color: '#00F2EA' }}>Dismiss</Text>
              </TouchableOpacity>
            </View>
          </Animated.View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B0B0C', paddingHorizontal: 16, justifyContent: 'space-between' },
  top: { marginTop: 8 },
  frostedContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#12121380',
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  urlInput: { flex: 1, color: '#E6F7F6', fontSize: 16 },
  pasteButton: { marginLeft: 8, padding: 6, borderRadius: 8 },
  middle: { marginTop: 18 },
  bentoRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  card: {
    width: (width - 48) / 2,
    height: 140,
    backgroundColor: '#0F0F10',
    borderRadius: 14,
    padding: 12,
    justifyContent: 'space-between',
  },
  cardTitle: { color: '#E6F7F6', fontWeight: '700', fontSize: 16 },
  cardSub: { color: '#8F9B9A', fontSize: 12 },
  bottom: { marginBottom: 24 },
  clipboardCard: { backgroundColor: '#0F13113', borderRadius: 14, padding: 16 },
  clipboardTitle: { color: '#00F2EA', fontWeight: '700', marginBottom: 6 },
  clipboardText: { color: '#E6F7F6', marginBottom: 12 },
  smallButton: { padding: 12, borderRadius: 10, backgroundColor: '#00F2EA' },
  smallButtonOutline: { padding: 12, borderRadius: 10, borderWidth: 1, borderColor: '#00F2EA' },
});