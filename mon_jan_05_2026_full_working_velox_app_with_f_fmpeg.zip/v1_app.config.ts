// app.config.ts
import { ExpoConfig, ConfigContext, withPlugins } from '@expo/config-plugins';
import withFFmpeg from './plugins/withFFmpeg';

export default ({ config }: ConfigContext): ExpoConfig => {
  return withPlugins(config, [
    // Custom FFmpeg + Foreground Service plugin
    withFFmpeg,
  ]) as ExpoConfig;
};

// Note:
// - All Android permissions and native wiring are applied by the plugin at prebuild time.
// - Make sure to replace package name / applicationId in android/app/build.gradle or use the project default.