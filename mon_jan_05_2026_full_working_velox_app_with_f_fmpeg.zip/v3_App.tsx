// App.tsx
import React from 'react';
import { StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import BentoHomeUI from './features/home/BentoHomeUI';
import BrowserScreen from './features/browser/BrowserScreen';
import VaultScreen from './features/vault/VaultScreen';
import DownloadQueueScreen from './features/queue/DownloadQueueScreen';
import DownloadManagerScreen from './features/flow/DownloadManagerScreen';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { QueryClient, QueryClientProvider } from 'react-query';

const Stack = createNativeStackNavigator();
const queryClient = new QueryClient();

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <QueryClientProvider client={queryClient}>
        <NavigationContainer>
          <StatusBar barStyle="light-content" backgroundColor="#0B0B0C" />
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Home" component={BentoHomeUI} />
            <Stack.Screen name="Browser" component={BrowserScreen} />
            <Stack.Screen name="Vault" component={VaultScreen} />
            <Stack.Screen name="Queue" component={DownloadQueueScreen} />
            <Stack.Screen name="Manager" component={DownloadManagerScreen} />
          </Stack.Navigator>
        </NavigationContainer>
      </QueryClientProvider>
    </GestureHandlerRootView>
  );
}