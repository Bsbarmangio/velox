package com.velox

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

// Foreground service with ability to update its persistent notification.
// The service reacts to two kinds of intents:
// - default start: startForeground with title/body
// - action "com.velox.ACTION_UPDATE_NOTIFICATION": update the current notification (title/body/progress)
class VeloxForegroundService : Service() {
    private val CHANNEL_ID = "velox_foreground_channel"
    private val NOTIF_ID = 4242
    private var lastTitle: String = "Velox"
    private var lastBody: String = "Processing media"
    private var lastProgress: Int? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val action = intent?.action
            val title = intent?.getStringExtra("title") ?: lastTitle
            val body = intent?.getStringExtra("body") ?: lastBody
            val progressExtra = if (intent != null && intent.hasExtra("progress")) intent.getFloatExtra("progress", -1f) else -1f
            val progress: Int? = if (progressExtra >= 0f) {
                val p = Math.round(progressExtra)
                lastProgress = p
                p
            } else {
                lastProgress
            }

            lastTitle = title
            lastBody = body

            // Build notification and set progress if provided
            val builder = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)

            if (progress != null) {
                // progress between 0..100
                val bounded = when {
                    progress < 0 -> 0
                    progress > 100 -> 100
                    else -> progress
                }
                builder.setProgress(100, bounded, false)
                builder.setContentText("$body • $bounded%")
            } else {
                builder.setProgress(0, 0, false)
            }

            val notification: Notification = builder.build()
            startForeground(NOTIF_ID, notification)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Keep service alive until explicitly stopped
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopForeground(true)
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Velox background",
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(channel)
        }
    }
}