// app.config.ts
import { ExpoConfig, ConfigContext, withPlugins } from '@expo/config-plugins';
import withFFmpeg from './plugins/withFFmpeg';

/**
 * Register the custom FFmpeg + Foreground Service plugin.
 */
export default ({ config }: ConfigContext): ExpoConfig => {
  return withPlugins(config, [withFFmpeg]) as ExpoConfig;
};