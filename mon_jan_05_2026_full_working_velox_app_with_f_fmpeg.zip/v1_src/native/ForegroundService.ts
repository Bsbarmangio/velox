// src/native/ForegroundService.ts
import { NativeModules, Platform } from 'react-native';

const { VeloxForegroundServiceModule } = NativeModules;

/**
 * JS wrapper around the native VeloxForegroundServiceModule
 * Methods:
 * - start(title, body)
 * - stop()
 *
 * If running on non-Android or module missing (e.g. in Expo Go prior to prebuild), these are no-ops.
 */
export async function startForegroundService(title = 'Velox', body = 'Processing media') {
  if (Platform.OS !== 'android' || !VeloxForegroundServiceModule) return false;
  try {
    await VeloxForegroundServiceModule.startService(title, body);
    return true;
  } catch (e) {
    console.warn('startForegroundService failed', e);
    return false;
  }
}

export async function stopForegroundService() {
  if (Platform.OS !== 'android' || !VeloxForegroundServiceModule) return false;
  try {
    await VeloxForegroundServiceModule.stopService();
    return true;
  } catch (e) {
    console.warn('stopForegroundService failed', e);
    return false;
  }
}